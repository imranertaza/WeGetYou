

<?php $__env->startSection('content'); ?>
	<div class="mainContent" aria-label="Welcome back!">
		<h1>Next step: complete the Quiz!</h1>
		<p>You search for a partner starts here. The answers you give on wegatyou's Compatibility Quiz helps us build your individual Personality Profile. This profile tells us what kind of person we should match with you. Once you've finished the Quiz, you can access your matches, profile and messaging</p>
	</div>
	<div class="submitRow">
		<a class="wdk-button t-primarySkin2 next " href="<?php echo e(url('/register/questionaire/3/'.$id)); ?>"><span class="text">Continue</span></a> 
	</div>
	
<?php $__env->stopSection(); ?>
               



<?php echo $__env->make('layouts.continuesteps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wegatyou(2)\wegatyou\resources\views/questionaire/step2.blade.php ENDPATH**/ ?>