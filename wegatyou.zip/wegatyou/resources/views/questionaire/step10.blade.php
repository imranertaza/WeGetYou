<!DOCTYPE html>
<html lang="en-US">
   <head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1 maximum-scale=1, user-scalable=0">
      <title>Questionaire</title>
	  <link rel="icon" href="{{ asset('/images/logo.png') }}" type="image/png">
      <link rel="stylesheet" type="text/css" href="{{ asset('/css/registration_combined.css') }}" />

   </head>
   <body id="questionnaireCheckpoint" class=" is-checkpoint_1 questionnaireCheckpoints questionnairePages is-heteroUser" >
      <div id="pageWrapper">
         <main id="content">
            <section class="showPage1">
               <article>
                  <div class="mainContent">
                     <div id="page1" class="page">
                        <h1>Great! You're over 40% done!</h1>
                     </div>
                     <div id="page2" class="page" aria-hidden="true">
                        <p>Our compatibility match system is already starting to fund matches for you</p>
                     </div>
                  </div>
                  <div class="submitRow">
                     <a id="buttonNext1" class="wdk-button t-primarySkin2 next " href="{{ url('/questionaire/about/'.$id) }}" > <span class="text">Continue</span> </a>
                  </div>
               </article>
            </section>
         </main>
         <footer id="footerUnified" class="registrationLayout">
            <nav>
               <ul>
                  <li>
                     <a id="footerLink1" href="" >About us</a>
                  </li>
                  <li>
                     <a id="footerLink2" href="" >Terms & conditions </a>
                  </li>
                  <li>
                     <a id="footerLink3" href="" rel="nofollow" >Privacy policy </a>
                  </li>
                  <li>
                     <a id="footerLink4" href="" >Help</a>
                  </li>
               </ul>
            </nav>
         </footer>
      </div>
   </body>
</html>


