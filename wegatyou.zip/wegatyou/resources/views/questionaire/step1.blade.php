@extends('layouts.continuesteps')

@section('content')
	<div class="mainContent" aria-label="Welcome back!">
		<h1>Welcome to our Compatibity Quiz</h1>
		<p>Thanks for registering! You've just completed the first step on your journey to a relationship</p>
	</div>
	<div class="submitRow">
		<a class="wdk-button t-primarySkin2 next " href="{{ url('/register/questionaire/2/'.$id) }}"><span class="text">Continue</span></a> 
	</div>
	
@endsection
               
