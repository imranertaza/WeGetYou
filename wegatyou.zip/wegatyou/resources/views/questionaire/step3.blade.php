@extends('layouts.continuesteps')

@section('content')
	<div class="mainContent" aria-label="Welcome back!" style="padding-top: 40px;">
		<h1>Our tips for getting the best results:</h1>
		<p>Take about 20 minutes to complete the Compatibility Quiz in peace and quiet</p>
		<p>Answer spontaneously and honestly - there are no right or wrong answers here</p>
		<p>After you've finished we'll show you your most compatible matches, based on your quiz results</p>
	</div>
	<div class="submitRow">
		<a class="wdk-button t-primarySkin2 next " href="{{ url('/register/questionaire/4/'.$id) }}"><span class="text">Continue</span></a> 
	</div>
	
@endsection
               


