@extends('layouts.continuesteps')

@section('content')
	<div class="mainContent" aria-label="Welcome back!">
		<h1>Next step: complete the Quiz!</h1>
		<p>You search for a partner starts here. The answers you give on wegatyou's Compatibility Quiz helps us build your individual Personality Profile. This profile tells us what kind of person we should match with you. Once you've finished the Quiz, you can access your matches, profile and messaging</p>
	</div>
	<div class="submitRow">
		<a class="wdk-button t-primarySkin2 next " href="{{ url('/register/questionaire/3/'.$id) }}"><span class="text">Continue</span></a> 
	</div>
	
@endsection
               


