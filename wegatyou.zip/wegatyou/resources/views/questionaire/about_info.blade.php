<p>Please give us some details to help fill out both your account and your profileImage</p>

</p>Tell us a little about you! Describe yourself, what you're looking for in a relationship, and/or about your ideal partner</p>

<form method="POST" action="{{ url('saveaboutinfo') }}">
	@csrf
	<input type="hidden" name="user_id" value="{{ $user_id }}">
	<textarea name="aboutinfo"></textarea>
	<input type="submit" value="Submit">
</form>
