@extends('layouts.main')

@section('styles')
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="{{ asset('css/app_combined.css') }}">
	<script src="{{ asset('/js/modernizr_combined.js') }}" nonce=""></script>
	<script defer="" src="{{ asset('/js/peg_logger.js?v=2') }}" nonce=""></script>
	<script defer="" src="{{ asset('/js/base_combined.js') }}" nonce=""></script>
	<script defer="" src="{{ asset('/js/app_combined.js') }}" nonce=""></script>
@endsection

@section('content')
   <body id="partnerProfilePage" class="profilePages noSubnavi ">
      <div id="appShellContent" class="">
         <div id="">
            <main id="content" class="is-visible" aria-hidden="false">
               <!-- For Mmenu -->
               <header id="profileHeader">
                  <div class="headerWrapper1">
                     <div id="bgImgBox" class="img_01_abstrakt-0017"></div>
                     <div id="sedCard">
                        <div id="photoBox">
                           <div class="photoWrapper useForVideoCallLayer">
                              <a href="" id="profilePicBM">
                                 <span class="u-photoProtector"> </span>
                                 <span class="photo clearPhoto"></span>
                              </a>
                           </div>
                           
                        </div>
                        <div id="mainUserInfo" class="">
                           <h2>
                              <span class="givenAliasName"></span>
                              <span class="bulletPoint"> • </span>
                              <span class="myNameText">{{ $user->first_name }} {{ $user->last_name }}</span>,
                              <span class="noBreakWrapper">
                              <span class="age">{{ $user->city.', '.$user->country}}</span>
                              </span>
                           </h2>
                           <h3>
<!--
                              <span class="occupation">Content Writer</span>
-->
                              <span class="iconWrapper">
                                 <span class="favoredProfile ">
                                 </span>
                              </span>
                           </h3>
                        </div>
                     </div>
                     <div id="profileMenu">
                        
                        <div id="profileMenuList" role="navigation" aria-hidden="true">
                           <ul>
                              <li>
                                 <p class="chiffre">
                                    <svg class="wdk-icon icon_user_female_100 " role="presentation">
                                       <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_user_female_100.svg?version=6.36.1/#icon_user_female_100"></use>
                                    </svg>
                                    Profile ID: EHMNDXRR
                                 </p>
                                 <button id="closePartnerProfileMenu" class="wdk-button t-plainSkin3 t-iconOnly " type="submit" aria-label="Close">
                                    <span class="icon">
                                       <svg class="wdk-icon icon_x " role="presentation">
                                          <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_x.svg?version=6.36.1/#icon_x"></use>
                                       </svg>
                                    </span>
                                    <span class="text">Close </span> 
                                 </button>
                              </li>
                              <li id="favoriteButton">
                                 <a id="favoriteProfile" class="wdk-button t-plainSkin3 wdk_loadingIndicator" href="#" data-url="/partner/favorite" data-partner-userid="EHMNDXRR">
                                    <span class="icon">
                                       <svg class="wdk-icon icon_star_2 " role="presentation">
                                          <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_star_2.svg?version=6.36.1/#icon_star_2"></use>
                                       </svg>
                                    </span>
                                    <span class="text"> <span class="addFavorite">Add to favorites</span> <span class="removeFavorite">Remove as Favourite</span> </span> <span class="trippleDot loader t-dark"></span> 
                                 </a>
                              </li>
                              <li id="aliasButton">
                                 <a id="giveAlias" class="wdk-button t-plainSkin3 wdk_loadingIndicator" href="#" data-open-modalbox-id="giveAliasModalbox">
                                    <span class="icon">
                                       <svg class="wdk-icon icon_address_book " role="presentation">
                                          <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_address_book.svg?version=6.36.1/#icon_address_book"></use>
                                       </svg>
                                    </span>
                                    <span class="text">Give nickname</span> <span class="trippleDot loader t-dark"></span> 
                                 </a>
                                 <div id="giveAliasModalbox" class="wdk-modalbox" data-url="/partner/givealias_layer?partnerChiffre=EHMNDXRR" data-close-on-esc="true" role="dialog" aria-modal="true" aria-hidden="true" inert="true"></div>
                                 <a id="editAlias" class="wdk-button t-plainSkin3 wdk_loadingIndicator" href="#" data-open-modalbox-id="editAliasModalbox">
                                    <span class="icon">
                                       <svg class="wdk-icon icon_address_book " role="presentation">
                                          <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_address_book.svg?version=6.36.1/#icon_address_book"></use>
                                       </svg>
                                    </span>
                                    <span class="text">Change nickname</span> <span class="trippleDot loader t-dark"></span> 
                                 </a>
                                 <div id="editAliasModalbox" class="wdk-modalbox" data-url="/partner/givealias_layer?partnerChiffre=EHMNDXRR" data-close-on-esc="true" role="dialog" aria-modal="true" aria-hidden="true" inert="true"></div>
                              </li>
                              <li id="rejectButton">
                                 <a id="rejectProfile" class="wdk-button t-plainSkin3 wdk_loadingIndicator" href="#" data-open-modalbox-id="rejectProfileModalbox">
                                    <span class="icon">
                                       <svg class="wdk-icon icon_forbidden " role="presentation">
                                          <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_forbidden.svg?version=6.36.1/#icon_forbidden"></use>
                                       </svg>
                                    </span>
                                    <span class="text">Remove match</span> <span class="trippleDot loader t-dark"></span> 
                                 </a>
                                 <div id="rejectProfileModalbox" class="wdk-modalbox" data-url="/partner/writemessage_layer/rejection?partnerUser=EHMNDXRR" data-close-on-esc="true" role="dialog" aria-modal="true" aria-hidden="true" inert="true"></div>
                                 <a id="rejectContact" class="wdk-button t-plainSkin3 wdk_loadingIndicator" href="#" data-open-modalbox-id="rejectContactModalbox">
                                    <span class="icon">
                                       <svg class="wdk-icon icon_forbidden " role="presentation">
                                          <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_forbidden.svg?version=6.36.1/#icon_forbidden"></use>
                                       </svg>
                                    </span>
                                    <span class="text">Discard Contact</span> <span class="trippleDot loader t-dark"></span> 
                                 </a>
                                 <div id="rejectContactModalbox" class="wdk-modalbox" data-url="/partner/writemessage_layer/reject_contact?partnerUser=EHMNDXRR" data-close-on-esc="true" role="dialog" aria-modal="true" aria-hidden="true" inert="true"></div>
                              </li>
                              <li id="reportButton">
                                 <a id="reportProfile" class="wdk-button t-plainSkin3 wdk_loadingIndicator" href="#" data-open-modalbox-id="reportProfileModalbox">
                                    <span class="icon">
                                       <svg class="wdk-icon icon_warning " role="presentation">
                                          <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_warning.svg?version=6.36.1/#icon_warning"></use>
                                       </svg>
                                    </span>
                                    <span class="text">Report Match</span> <span class="trippleDot loader t-dark"></span> 
                                 </a>
                                 <div id="reportProfileModalbox" class="wdk-modalbox" data-url="/partner/report_profile?partnerId=EHMNDXRR" data-close-on-esc="true" role="dialog" aria-modal="true" aria-hidden="true" inert="true"></div>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div id="favoriteProfileSuccess" class="wdk-toast t-small" aria-hidden="true">
                        Added to favorites 
                     </div>
                     <div id="unfavoriteProfileSuccess" class="wdk-toast t-small" aria-hidden="true">
                        Removed from reminder list 
                     </div>
                     <div id="reportProfileSuccessfull" class="wdk-toast t-small" aria-hidden="true">
                        Many thanks for reporting this profile.
                        <br><br>
                        We will check the profile accordingly. 
                     </div>
                     <div id="editAliasSuccessfull" class="wdk-toast t-small" aria-hidden="true">
                        Assign name 
                     </div>
                     <a id="partnerPagerPrev" class="partnerPager disabled" href="#"></a>
                     <a id="partnerPagerNext" class="partnerPager disabled" href="#"></a>
                  </div>
                  <div class="headerWrapper2">
                     <div class="moreInfoBox">
                        <div id="matchingPoints">
<!--
                           <div class="matchingHeart showHeartWithAnimation"></div>
                           <div class="displayMP ">104</div>
-->
                        </div>
                       
                        <div id="communicationButtons" data-reload-url="/partner/contact_buttons?chiffre=EHMNDXRR">
                           <button id="selectMessage" class="wdk-button t-primarySkin1 t-circle t-size_200 js-onlineOnly showAnimation" type="button">
                              <span class="icon">
                                 <svg class="wdk-icon icon_message " role="presentation">
                                    <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_message.svg?version=6.36.1/#icon_message"></use>
                                 </svg>
                              </span>
                              <span class="text"></span> 
                           </button>
                           
                        </div>
                     </div>
                  </div>
                  <nav id="profileTabNavi" data-scroll-to-tab-navi="" aria-label="Profile Tabs" class="showSwiperArrows">
                     <ul class="dragscroll">
                        <li id="profileTab" class="wdk_loadingIndicator active" data-content-url="/partner/profile_tab?userid=EHMNDXRR" data-content-loaded="true" data-tracking-name="PROFILE_TAB">
                           <a href="#">
                           <span class="text">
                           <span class="hideInM hideInLXL">Profile</span>
                           <span class="hideInS">About</span>
                           </span>
                           <span class="trippleDot loader t-dark"></span>
                           </a>
                        </li>
                        
                     </ul>
                  </nav>
               </header>
               <div id="tabContents">
                  <div id="profileTabContent" class="active">
                     <section class="wdk-cardDeck js-withMagicCards shuffleDone">
                        <div class="primaryCol">
                           <article id="personalStatementCard" data-2column-position="primary">
                              <h2>Introduction</h2>
                              <p class="personalStatementText">{{ $user->aboutinfo }}</p>
                              
                           </article>
<!--
                           <article id="aboutmeCard" data-2column-position="primary">
                              <h2>About me</h2>
                              <div class="aboutMeQuestionsWrapper">
                                 <ul id="aboutMeQuestions">
                                    <li id="question_39">
                                       <h4>I wish I could ...</h4>
                                       <p>I wish I could be more useful to my community. I wholeheartedly believe that community is an important part of healthy social living. </p>
                                       <span id="like_aboutMeAnswer39" class="likeIt js-onlineOnly" data-likeurl="/like/aboutMeAnswer?id=39"></span>
                                    </li>
                                    <li id="question_52">
                                       <h4>If I am in a bad mood...</h4>
                                       <p>If im in a bad mood I like to spend some time restoring order. I would clean up my surrounding and make some balanced meals and go out for a long walk. </p>
                                       <span id="like_aboutMeAnswer52" class="likeIt js-onlineOnly" data-likeurl="/like/aboutMeAnswer?id=52"></span>
                                    </li>
                                 </ul>
                              </div>
                           </article>
-->
                           <article id="similaritiesCard" data-2column-position="primary">
                              <h2>Lifestyle</h2>
                              <div id="INTERESTS" class="similarities">
                                 <h4>Interests and Hobbies</h4>
                                 <ul>
									 @if(count($hobbiesArr) > 0)
										 @foreach($hobbiesArr as $hobby)
											<li>{{ $hobby }}</li>
										 @endforeach
									@endif
                                 </ul>
                              </div>
                              <div id="SPORTS" class="similarities">
                                 <h4>Music</h4>
                                 <ul>
									 @if(count($musicArr) > 0)
										 @foreach($musicArr as $music)
											<li>{{ $music }}</li>
										 @endforeach
									@endif
                                 </ul>
                              </div>
                              <div id="HOLIDAY" class="similarities">
                                 <h4>Travelling</h4>
                                 <ul>
									@if(count($holidayArr) > 0)
										@foreach($holidayArr as $holiday)
											<li>{{ $holiday }}</li>
										 @endforeach
									@else
										<li>N/A</li>
									@endif
                                 </ul>
                              </div>
                              
                              <div id="HOLIDAY" class="similarities">
                                 <h4>Food Preference</h4>
                                 <ul>
									@if (!count($pref)==0)
										@foreach ($pref as $one)
											<li id="foodPref_{{$one->id}}">{{ $one->food_pref }}</li>
										 @endforeach
									@else
										<li>N/A</li>
									@endif
                                 </ul>
                              </div>
                              <div id="HOLIDAY" class="similarities">
                                 <h4>Favorite Food<span class="float-right"><i class="fas fa-edit px-3 openEditState"></i><i class="fas fa-times px-3 d-none closeEditState"></i></span></h4>
                                 <ul>
									@if (!count($userFavoriteFoods)==0)
										@foreach ($userFavoriteFoods as $one)
										<li id="favorite_f{{$one->id}}">{{ $one->favorite_food }}</li>
										@endforeach
									
									@else
										-You have no favorite foods !!!<br>
										Update your profile to enhance your profile.
									@endif
                                 </ul>
                                 <div class="editState d-none mt-2">
									@if (!count($pref)==0)
											@foreach ($userFavoriteFoods as $one)
												<div class="edit-state-element" id="{{$one->id}}">
													{{$one->favorite_food}}
													<i class="fas fa-times pl-2"></i>
												</div>
											@endforeach
									@endif
									<form  id="favoriteFoodForm" class="mt-3 d-flex justify-content-center align-items-center">
										@csrf
										<select multiple id="favoriteFoods"></select>
										<button type="submit" class="btn btn-outline-primary btn-sm ml-3">Add</button>
									</form>
								</div>
                              </div>
                              <div id="HOLIDAY" class="similarities">
                                 <h4>Favorite Drink<span class="float-right"><i class="fas fa-edit px-3 openEditState"></i><i class="fas fa-times px-3 d-none closeEditState"></i></span></h4>
                                 <ul>
									@if (!count($userFavoriteDrinks)==0)
										@foreach ($userFavoriteDrinks as $one)
										<li id="favorite_d{{$one->id}}">{{ $one->favorite_drink }}</li>
										@endforeach
									@else    
										-You have no favorite drinks !!!<br>
										Update your profile to enhance your profile.
									@endif
                                 </ul>
                                 <div class="editState d-none my-2">
									@if (!count($pref)==0)
											@foreach ($userFavoriteDrinks as $one)
												<div class="edit-state-element" id="{{$one->id}}">
													{{$one->favorite_drink}}
													<i class="fas fa-times pl-2"></i>
												</div>
											@endforeach
									@endif
									<form  id="favoriteDrinkForm" class="mt-3 d-flex justify-content-center align-items-center">
										@csrf
										<select multiple id="favoriteDrinks"></select>
										<button type="submit" class="btn btn-outline-primary btn-sm ml-3">Add</button>
									</form>
								</div>
                              </div>
                           </article>
                        </div>
                        <div class="secondaryCol">
                           <article id="factfileCard" data-2column-position="secondary" class="profileBigIconCard is-close">
                              <h2>Factfile</h2>
                              <ul class="lessFactfileItems">
                                 <li id="region">
                                    <span class="wdk-icon factfileIcon itemIcon">
                                    <img src="{{ asset('/images/icon_location_pin.svg') }}" alt="City of residence" loading="lazy">
                                    </span>
                                    <h4>City of residence</h4>
                                    <span class="factfileValue itemValue">
                                       {{ $user->city.', '.$user->country}}, 
                                    </span>
                                 </li>
                                 <li id="bodyType">
                                    <span class="wdk-icon factfileIcon itemIcon">
<!--
                                    <img src="assets/images/icon_figure_ruler.svg" alt="Body type" loading="lazy">
-->
                                    </span>
                                    <h4>Date of Birth</h4>
                                    <span class="factfileValue itemValue">{{ date('d/m/Y',strtotime($user->b_day)) }}</span>
                                 </li>
                                 <li id="ethnicity">
                                    <span class="wdk-icon factfileIcon itemIcon">
<!--
                                    <img src="assets/images/icon_earth.svg" alt="Ethnicity" loading="lazy">
-->
                                    </span>
                                    <h4>Sex</h4>
                                    <span class="factfileValue itemValue">
                                    {{ $user->sex }} </span>
                                 </li>
                              </ul>
                              
<!--
                              <ul class="moreFactfileItems">
                                 <li id="education">
                                    <span class="wdk-icon factfileIcon itemIcon">
                                    <img src="assets/images/icon_academic_cap.svg" alt="Degree" loading="lazy">
                                    </span>
                                    <h4>Degree</h4>
                                    <span class="factfileValue itemValue">
                                    University/college degree(s)
                                    </span>
                                 </li>
                                 <li id="smoker">
                                    <span class="wdk-icon factfileIcon itemIcon">
                                    <img src="assets/images/icon_cigarette.svg" alt="Smoking" loading="lazy">
                                    </span>
                                    <h4>Smoking</h4>
                                    <span class="factfileValue itemValue">
                                    Non-smoker </span>
                                 </li>
                                 <li id="sport">
                                    <span class="wdk-icon factfileIcon itemIcon">
                                    <img src="assets/images/icon_dumbbell.svg" alt="How often do you workout?
                                       " loading="lazy">
                                    </span>
                                    <h4>How often do you workout?</h4>
                                    <span class="factfileValue itemValue">
                                    Several times a month </span>
                                 </li>
                                 <li id="maritalstatus">
                                    <span class="wdk-icon factfileIcon itemIcon">
                                    <img src="assets/images/icon_wedding_rings.svg" alt="Marital status" loading="lazy">
                                    </span>
                                    <h4>Marital status</h4>
                                    <span class="factfileValue itemValue">
                                    Single </span>
                                 </li>
                                 <li id="children">
                                    <span class="wdk-icon factfileIcon itemIcon">
                                    <img src="assets/images/icon_child_figures.svg" alt="Children" loading="lazy">
                                    </span>
                                    <h4>Children</h4>
                                    <span class="factfileValue itemValue">
                                    No children </span>
                                 </li>
                                 <li id="religion">
                                    <span class="wdk-icon factfileIcon itemIcon">
                                    <img src="assets/images/icon_pray.svg" alt="Religion" loading="lazy">
                                    </span>
                                    <h4>Religion</h4>
                                    <span class="factfileValue itemValue">
                                    Spiritual but not religious </span>
                                 </li>
                              </ul>
                              <div class="buttonsWrapper buttonLess">
                                 <button class="wdk-button t-outlineSkin2 js-toggleCollapse " type="submit">
                                    <span class="text">
                                       Less 
                                       <svg class="wdk-icon icon_arrow_up_bold " role="presentation">
                                          <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_arrow_up_bold.svg?version=6.36.1/#icon_arrow_up_bold"></use>
                                       </svg>
                                    </span>
                                 </button>
                              </div>
                           
-->
							</article>
<!--
                           <article id="matchingCard" data-2column-position="secondary" class="has-slideUpAnimation startSlideUp">
                              <h2>Your compatibility level</h2>
                              <div id="matchingCircle" class="animate">
                                 <div class="photoWrap partnerPic">
                                    <span class="u-photoProtector"></span>
                                    <span class="photo"></span>
                                 </div>
                                 <div class="photoWrap myPic">
                                    <span class="u-photoProtector"></span>
                                    <span class="photo"></span>
                                 </div>
                                 <div class="matchingPoints">
                                    <div class="matchingHeart"></div>
                                    <div class="displayMP ">104</div>
                                 </div>
                              </div>
                              <button class="wdk-button t-primarySkin2 " type="submit"> <span class="text"> See more</span> </button>
                           </article>
-->
<!--
                           <article class="urcCard t-noCardDesign hideInLXL has-slideUpAnimation" data-2column-position="secondary" aria-hidden="true" style="">
                              <div class="js-loadURCviaAjax" data-slotname="pc_partner_factfile_top" data-viewname="/urcontent/layout/image" data-show-in-viewports="S,M" data-wrapper-template="/urcontent/slot_wrapper/urc_card"></div>
                           </article>
                           <article id="entertainmentCard" class="profileBigIconCard" data-2column-position="secondary">
                              <h2>Entertainment</h2>
                              <ul>
                                 <li id="musicalTaste">
                                    <span class="wdk-icon itemIcon">
                                    <img src="assets/images/icon_headphones.svg" alt="Music:" loading="lazy">
                                    </span>
                                    <h4>Music:</h4>
                                    <span class="entertainmentValue itemValue">Alternative, Blues, Easy Listening, Folk music, Funk/Soul, Gospel, Jazz</span>
                                 </li>
                              </ul>
                           </article>
-->
<!--
                           <article class="urcCard t-noCardDesign has-slideUpAnimation hideInLXL" data-2column-position="secondary" aria-hidden="true" style="">
                              <div class="js-loadURCviaAjax" data-slotname="pc_partner_factfile_mobile" data-viewname="/urcontent/layout/image" data-show-in-viewports="S,M" data-wrapper-template="/urcontent/slot_wrapper/urc_card"></div>
                           </article>
                           <article class="urcCard t-noCardDesign has-slideUpAnimation hideInSM" data-2column-position="secondary" aria-hidden="true">
                           </article>
-->
                        </div>

                           </div>
                        </div>
                     </section>
                  </div>
               </div>

            </main>
            <footer id="footerUnified" class="appLayout" aria-hidden="false">
               <nav>
                  <ul>
                     <li>
                        <a id="footerLink1" href="#">About us</a>
                     </li>
                     <li>
                        <a id="footerLink2" href="#">Terms &amp; conditions </a>
                     </li>
                     <li>
                        <a id="footerLink3" href="#" rel="nofollow">Privacy policy </a>
                     </li>
                     <li>
                        <a id="footerLink4" href="#">Help</a>
                     </li>
                     <li>
                        <a id="footerLink5" href="#">Safety</a>
                     </li>
                     <li>
                        <a id="footerLink6" href="#">Affiliates</a>
                     </li>
                  </ul>
               </nav>
            </footer>
         </div>
      </div>
   </body>
</html>
@endsection
