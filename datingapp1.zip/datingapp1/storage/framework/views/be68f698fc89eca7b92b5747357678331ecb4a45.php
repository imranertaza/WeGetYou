<?php $__env->startSection('styles'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('css/homepage.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app_combined.css')); ?>">
	<script src="<?php echo e(asset('/js/modernizr_combined.js')); ?>" nonce=""></script>
	<script defer="" src="<?php echo e(asset('/js/peg_logger.js?v=2')); ?>" nonce=""></script>
	<script defer="" src="<?php echo e(asset('/js/base_combined.js')); ?>" nonce=""></script>
	<script defer="" src="<?php echo e(asset('/js/app_combined.js')); ?>" nonce=""></script>
	<style>
   .navbar { background-color: rgba(214, 0, 35, 0.02) !important; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <body id="partnerProfilePage" class="profilePages noSubnavi ">
      <div id="appShellContent" class="">
         <div id="">
            <main id="content" class="is-visible" aria-hidden="false">
               <!-- For Mmenu -->
               <header id="profileHeader">
                  <div class="headerWrapper1">
                     <div id="bgImgBox" class="img_01_abstrakt-0017"></div>
                     <div id="sedCard">
                        <div id="photoBox">
                           <div class="photoWrapper useForVideoCallLayer">
                              <a href="javascript:void(0)" id="profilePicBM">
								 <img src="<?php echo e(asset('storage/profile_pictures/'.$profileInfo->profile_picture)); ?>" alt="">
                                 <span class="u-photoProtector"> </span>
                                 <span class="photo clearPhoto"></span>
                              </a>
                           </div>
                        </div>
                        <div id="mainUserInfo" class="">
                           <h2>
                              <span class="givenAliasName"></span>
                              <span class="bulletPoint"> • </span>
                              <span class="myNameText"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></span>,
                              <span class="noBreakWrapper">
                              <span class="age"><?php echo e($user->city.', '.$user->country); ?></span>
                              </span>
                           </h2>
                           <h3>
                              <span class="iconWrapper">
                                 <span class="favoredProfile ">
                                 </span>
                              </span>
                           </h3>
                        </div>
                     </div>
                     <div id="profileMenu">
                        <div id="profileMenuList" role="navigation" aria-hidden="true">
                           <ul>
                              <li>
                                 <p class="chiffre">
                                    <svg class="wdk-icon icon_user_female_100 " role="presentation">
                                       <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_user_female_100.svg?version=6.36.1/#icon_user_female_100"></use>
                                    </svg>
                                    Profile ID: EHMNDXRR
                                 </p>
                                 <button id="closePartnerProfileMenu" class="wdk-button t-plainSkin3 t-iconOnly " type="submit" aria-label="Close">
                                    <span class="icon">
                                       <svg class="wdk-icon icon_x " role="presentation">
                                          <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_x.svg?version=6.36.1/#icon_x"></use>
                                       </svg>
                                    </span>
                                    <span class="text">Close </span> 
                                 </button>
                              </li>
                              <li id="favoriteButton">
                                 <a id="favoriteProfile" class="wdk-button t-plainSkin3 wdk_loadingIndicator" href="#" data-url="/partner/favorite" data-partner-userid="EHMNDXRR">
                                    <span class="icon">
                                       <svg class="wdk-icon icon_star_2 " role="presentation">
                                          <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_star_2.svg?version=6.36.1/#icon_star_2"></use>
                                       </svg>
                                    </span>
                                    <span class="text"> <span class="addFavorite">Add to favorites</span> <span class="removeFavorite">Remove as Favourite</span> </span> <span class="trippleDot loader t-dark"></span> 
                                 </a>
                              </li>
                              <li id="aliasButton">
                                 <a id="giveAlias" class="wdk-button t-plainSkin3 wdk_loadingIndicator" href="#" data-open-modalbox-id="giveAliasModalbox">
                                    <span class="icon">
                                       <svg class="wdk-icon icon_address_book " role="presentation">
                                          <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_address_book.svg?version=6.36.1/#icon_address_book"></use>
                                       </svg>
                                    </span>
                                    <span class="text">Give nickname</span> <span class="trippleDot loader t-dark"></span> 
                                 </a>
                                 <div id="giveAliasModalbox" class="wdk-modalbox" data-url="/partner/givealias_layer?partnerChiffre=EHMNDXRR" data-close-on-esc="true" role="dialog" aria-modal="true" aria-hidden="true" inert="true"></div>
                                 <a id="editAlias" class="wdk-button t-plainSkin3 wdk_loadingIndicator" href="#" data-open-modalbox-id="editAliasModalbox">
                                    <span class="icon">
                                       <svg class="wdk-icon icon_address_book " role="presentation">
                                          <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_address_book.svg?version=6.36.1/#icon_address_book"></use>
                                       </svg>
                                    </span>
                                    <span class="text">Change nickname</span> <span class="trippleDot loader t-dark"></span> 
                                 </a>
                                 <div id="editAliasModalbox" class="wdk-modalbox" data-url="/partner/givealias_layer?partnerChiffre=EHMNDXRR" data-close-on-esc="true" role="dialog" aria-modal="true" aria-hidden="true" inert="true"></div>
                              </li>
                              <li id="rejectButton">
                                 <a id="rejectProfile" class="wdk-button t-plainSkin3 wdk_loadingIndicator" href="#" data-open-modalbox-id="rejectProfileModalbox">
                                    <span class="icon">
                                       <svg class="wdk-icon icon_forbidden " role="presentation">
                                          <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_forbidden.svg?version=6.36.1/#icon_forbidden"></use>
                                       </svg>
                                    </span>
                                    <span class="text">Remove match</span> <span class="trippleDot loader t-dark"></span> 
                                 </a>
                                 <div id="rejectProfileModalbox" class="wdk-modalbox" data-url="/partner/writemessage_layer/rejection?partnerUser=EHMNDXRR" data-close-on-esc="true" role="dialog" aria-modal="true" aria-hidden="true" inert="true"></div>
                                 <a id="rejectContact" class="wdk-button t-plainSkin3 wdk_loadingIndicator" href="#" data-open-modalbox-id="rejectContactModalbox">
                                    <span class="icon">
                                       <svg class="wdk-icon icon_forbidden " role="presentation">
                                          <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_forbidden.svg?version=6.36.1/#icon_forbidden"></use>
                                       </svg>
                                    </span>
                                    <span class="text">Discard Contact</span> <span class="trippleDot loader t-dark"></span> 
                                 </a>
                                 <div id="rejectContactModalbox" class="wdk-modalbox" data-url="/partner/writemessage_layer/reject_contact?partnerUser=EHMNDXRR" data-close-on-esc="true" role="dialog" aria-modal="true" aria-hidden="true" inert="true"></div>
                              </li>
                              <li id="reportButton">
                                 <a id="reportProfile" class="wdk-button t-plainSkin3 wdk_loadingIndicator" href="#" data-open-modalbox-id="reportProfileModalbox">
                                    <span class="icon">
                                       <svg class="wdk-icon icon_warning " role="presentation">
                                          <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_warning.svg?version=6.36.1/#icon_warning"></use>
                                       </svg>
                                    </span>
                                    <span class="text">Report Match</span> <span class="trippleDot loader t-dark"></span> 
                                 </a>
                                 <div id="reportProfileModalbox" class="wdk-modalbox" data-url="/partner/report_profile?partnerId=EHMNDXRR" data-close-on-esc="true" role="dialog" aria-modal="true" aria-hidden="true" inert="true"></div>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div id="favoriteProfileSuccess" class="wdk-toast t-small" aria-hidden="true">
                        Added to favorites 
                     </div>
                     <div id="unfavoriteProfileSuccess" class="wdk-toast t-small" aria-hidden="true">
                        Removed from reminder list 
                     </div>
                     <div id="reportProfileSuccessfull" class="wdk-toast t-small" aria-hidden="true">
                        Many thanks for reporting this profile.
                        <br><br>
                        We will check the profile accordingly. 
                     </div>
                     <div id="editAliasSuccessfull" class="wdk-toast t-small" aria-hidden="true">
                        Assign name 
                     </div>
                     <a id="partnerPagerPrev" class="partnerPager disabled" href="#"></a>
                     <a id="partnerPagerNext" class="partnerPager disabled" href="#"></a>
                  </div>
                  <div class="headerWrapper2">
                     <div class="moreInfoBox">
                        <div id="matchingPoints">
                        </div>
                       
                        <div id="communicationButtons" data-reload-url="/partner/contact_buttons?chiffre=EHMNDXRR">
                           <button id="selectMessage" class="wdk-button t-primarySkin1 t-circle t-size_200 js-onlineOnly showAnimation" type="button">
                              <span class="icon">
                                 <svg class="wdk-icon icon_message " role="presentation">
                                    <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_message.svg?version=6.36.1/#icon_message"></use>
                                 </svg>
                              </span>
                              <span class="text"></span> 
                           </button>
                           
                        </div>
                     </div>
                  </div>
                  <nav id="profileTabNavi" data-scroll-to-tab-navi="" aria-label="Profile Tabs" class="showSwiperArrows">
                     <ul class="dragscroll">
                        <li id="profileTab" class="wdk_loadingIndicator active" data-content-url="/partner/profile_tab?userid=EHMNDXRR" data-content-loaded="true" data-tracking-name="PROFILE_TAB">
                           <a href="#">
                           <span class="text">
                           <span class="hideInM hideInLXL">Profile</span>
                           <span class="hideInS">About</span>
                           </span>
                           <span class="trippleDot loader t-dark"></span>
                           </a>
                        </li>
                        
                     </ul>
                  </nav>
               </header>
               <div id="tabContents">
                  <div id="profileTabContent" class="active">
                     <section class="wdk-cardDeck js-withMagicCards shuffleDone">
                        <div class="primaryCol">
                           <article id="personalStatementCard" data-2column-position="primary">
                              <h2>Introduction<span class="float-right"><i class="fas fa-edit px-3" id="abt_edit_icon" onclick="showAbtForm()"></i><i class="fas fa-times px-3 d-none"  id="abt_cross_icon" onclick="hideAbtForm()"></i></span></h2>
                              <p class="personalStatementText"><?php echo e($userabout->aboutinfo ? $userabout->aboutinfo : 'N/A'); ?></p>
                              <form class="abt-from" id="abt-from-id" style="display:none;">
									<?php echo csrf_field(); ?>
									<textarea name="aboutinfo" id="about_info_txt" rows="10" style="width:100%"><?php echo e($userabout->aboutinfo); ?></textarea>
									<button type="submit" class="btn btn-outline-primary btn-sm ml-3">Save</button>
								</form>
                           </article>
                           <article id="similaritiesCard" data-2column-position="primary">
                              <h2>Lifestyle</h2>
                              <div id="interests" class="similarities">
                                 <h4>Interests and Hobbies<span class="float-right"><i class="fas fa-edit px-3 openEditState"></i><i class="fas fa-times px-3 d-none closeEditState"></i></span></h4>
                                 <ul class="showState">
									 <?php if(count($hobbiesArr) > 0): ?>
										 <?php $__currentLoopData = $hobbiesArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hobby_key => $hobby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li id="hobby_d<?php echo e($hobby_key); ?>"><?php echo e($hobby); ?></li>
										 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php else: ?>
										<li>N/A</li>
									<?php endif; ?>
                                 </ul>
                                 <div class="editState d-none mt-2">
								
									<?php if(!count($hobbiesArr)==0): ?>
										<?php $__currentLoopData = $hobbiesArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hobby_key => $hobby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="edit-state-element" id="<?php echo e($hobby_key); ?>">
												<?php echo e($hobby); ?>

												<i class="fas fa-times pl-2"></i>
											</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
									<form id="hobbyForm" class="mt-3 d-flex justify-content-center align-items-center">
										<?php echo csrf_field(); ?>
										<select multiple id="hobbie_select">
											<?php $__currentLoopData = $hobbieTableData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hobby_key => $hobby_table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($hobby_key); ?>"><?php echo e($hobby_table['hobbie']); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
										<button type="submit" class="btn btn-outline-primary btn-sm ml-3">Add</button>
									</form>
								</div>
                              </div>
                              <div id="music" class="similarities">
                                 <h4>Music<span class="float-right"><i class="fas fa-edit px-3 openEditState"></i><i class="fas fa-times px-3 d-none closeEditState"></i></span></h4>
                                 <ul class="showState">
									 <?php if(count($musicArr) > 0): ?>
										 <?php $__currentLoopData = $musicArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $music_key => $music): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li id="music_d<?php echo e($music_key); ?>"><?php echo e($music); ?></li>
										 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php else: ?>
										<li>N/A</li>
									<?php endif; ?>
                                 </ul>
                                 <div class="editState d-none mt-2">
								
									<?php if(!count($musicArr)==0): ?>
										<?php $__currentLoopData = $musicArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $music_key => $music): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="edit-state-element" id="<?php echo e($music_key); ?>">
												<?php echo e($music); ?>

												<i class="fas fa-times pl-2"></i>
											</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
									<form id="musicForm" class="mt-3 d-flex justify-content-center align-items-center">
										<?php echo csrf_field(); ?>
										<select multiple id="music_select">
											<?php $__currentLoopData = $musicTableData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $music_key => $music_table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($music_key); ?>"><?php echo e($music_table['music']); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
										<button type="submit" class="btn btn-outline-primary btn-sm ml-3">Add</button>
									</form>
								</div>
							
                              </div>
                              
                              <div id="holiday" class="similarities">
							 <h4>Travelling<span class="float-right"><i class="fas fa-edit px-3 openEditState"></i><i class="fas fa-times px-3 d-none closeEditState"></i></span></h4>
							 <ul class="showState">
								<?php if(count($holidayArr) > 0): ?>
									
									<?php $__currentLoopData = $holidayArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holiday_key => $holiday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li id="holiday_d<?php echo e($holiday_key); ?>"><?php echo e($holiday); ?></li>
									 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php else: ?>
									<li>N/A</li>
								<?php endif; ?>
							 </ul>
							 <div class="editState d-none mt-2">
								
								<?php if(!count($holidayArr)==0): ?>
									<?php $__currentLoopData = $holidayArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holiday_key => $holiday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="edit-state-element"  id="<?php echo e($holiday_key); ?>">
											<?php echo e($holiday); ?>

											<i class="fas fa-times pl-2"></i>
										</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								<form id="holidayForm" class="mt-3 d-flex justify-content-center align-items-center">
									<?php echo csrf_field(); ?>
									<select multiple id="holiday_select">
										<?php $__currentLoopData = $holidaysTableData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holiday_key => $holiday_table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($holiday_key); ?>"><?php echo e($holiday_table['holiday']); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<button type="submit" class="btn btn-outline-primary btn-sm ml-3">Add</button>
								</form>
							</div>
							</div>
                              
                              <div class="similarities" id="pref">
                                 <h4>Food Preference<span class="float-right"><i class="fas fa-edit px-3 openEditState"></i><i class="fas fa-times px-3 d-none closeEditState"></i></span></h4>
                                 <ul class="showState">
									<?php if(!count($pref)==0): ?>
										
										<?php $__currentLoopData = $pref; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li id="foodPref_<?php echo e($one->id); ?>"><?php echo e($one->food_pref); ?></li>
										 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php else: ?>
										<li>N/A</li>
									<?php endif; ?>
                                 </ul>
                                 <div class="editState d-none mt-2">
                                    <?php if(!count($pref)==0): ?>
										<?php $__currentLoopData = $pref; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="edit-state-element" id="<?php echo e($one->id); ?>">
												<?php echo e($one->food_pref); ?>

												<i class="fas fa-times pl-2"></i>
											</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    <form id="prefForm" class="mt-3 d-flex justify-content-center align-items-center">
                                        <?php echo csrf_field(); ?>
                                        <select multiple id="preferences"></select>
                                        <button type="submit" class="btn btn-outline-primary btn-sm ml-3">Add</button>
                                    </form>
                                </div>
                              </div>
                              <div class="similarities" id="favoriteFood">
                                 <h4>Favorite Food<span class="float-right"><i class="fas fa-edit px-3 openEditState"></i><i class="fas fa-times px-3 d-none closeEditState"></i></span></h4>
                                 <ul class="showState">
         									<?php if(!count($userFavoriteFoods)==0): ?>
         										<?php $__currentLoopData = $userFavoriteFoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         										<li id="favorite_f<?php echo e($one->id); ?>"><?php echo e($one->favorite_food); ?></li>
         										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         									
         									<?php else: ?>
         										-You have no favorite foods !!!<br>
         										Update your profile to enhance your profile.
         									<?php endif; ?>
                                 </ul>
                                 <div class="editState d-none mt-2">
         									<?php if(!count($pref)==0): ?>
         											<?php $__currentLoopData = $userFavoriteFoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         												<div class="edit-state-element" id="<?php echo e($one->id); ?>">
         													<?php echo e($one->favorite_food); ?>

         													<i class="fas fa-times pl-2"></i>
         												</div>
         											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         									<?php endif; ?>
         									<form  id="favoriteFoodForm" class="mt-3 d-flex justify-content-center align-items-center">
         										<?php echo csrf_field(); ?>
         										<select multiple id="favoriteFoods"></select>
         										<button type="submit" class="btn btn-outline-primary btn-sm ml-3">Add</button>
         									</form>
         								</div>
                              </div>
                              <div class="similarities" id="favoriteDrink">
                                 <h4>Favorite Drink<span class="float-right"><i class="fas fa-edit px-3 openEditState"></i><i class="fas fa-times px-3 d-none closeEditState"></i></span></h4>
                                 <ul class="showState">
									<?php if(!count($userFavoriteDrinks)==0): ?>
										<?php $__currentLoopData = $userFavoriteDrinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li id="favorite_d<?php echo e($one->id); ?>"><?php echo e($one->favorite_drink); ?></li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php else: ?>    
										-You have no favorite drinks !!!<br>
										Update your profile to enhance your profile.
									<?php endif; ?>
                                 </ul>
                                 <div class="editState d-none my-2">
									<?php if(!count($pref)==0): ?>
											<?php $__currentLoopData = $userFavoriteDrinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<div class="edit-state-element" id="<?php echo e($one->id); ?>">
													<?php echo e($one->favorite_drink); ?>

													<i class="fas fa-times pl-2"></i>
												</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
									<form  id="favoriteDrinkForm" class="mt-3 d-flex justify-content-center align-items-center">
										<?php echo csrf_field(); ?>
										<select multiple id="favoriteDrinks"></select>
										<button type="submit" class="btn btn-outline-primary btn-sm ml-3">Add</button>
									</form>
								</div>
                              </div>
                           </article>
                        </div>
                        <div class="secondaryCol">
                           <article id="factfileCard" data-2column-position="secondary" class="profileBigIconCard is-close">
                              <h2>Factfile</h2>
                              <ul class="lessFactfileItems">
								  <li id="membership">
									  <span class="wdk-icon factfileIcon itemIcon"></span>
									  <h4>Membership</h4>
									  <span class="factfileValue itemValue">
										  <?php if($profileInfo->subscribtion == 0): ?>
											<?php $subscription = 'N/A'; ?>
										  <?php elseif($profileInfo->subscribtion == 1): ?>
											<?php $subscription = 'Mizar'; ?>
										  <?php elseif($profileInfo->subscribtion == 2): ?>
											<?php $subscription = 'Premium'; ?>
										  <?php elseif($profileInfo->subscribtion == 3): ?>
											<?php $subscription = 'Gold'; ?>
										  <?php endif; ?>
                                       <?php echo e($subscription); ?>

                                      
                                       <?php if($profileInfo->subscribtion == 0): ?>
											<a class="btn btn-primary" href="<?php echo e(url('/subscribtion')); ?>" style="    text-decoration: none;">Purchase Subscription</a>
                                       <?php elseif($profileInfo->subscribtion == 1): ?>
										 <a class="btn btn-primary" href="<?php echo e(url('/subscribtion')); ?>" style="    text-decoration: none;">Upgrade Subscription</a>
                                       <?php endif; ?>
                                       </span>
                                     
								  </li>
                                 <li id="region">
                                    <span class="wdk-icon factfileIcon itemIcon">
<!--
                                    <img src="<?php echo e(asset('/images/icon_location_pin.svg')); ?>" alt="City of residence">
-->
                                    </span>
                                    <h4>City of residence<span><i class="fas fa-edit px-3" id="loc_edit" onclick="showLocForm()"></i><i class="fas fa-times px-3 d-none" id="loc_close" onclick="hideLocForm()"></i></span></h4>
                                    <span class="factfileValue itemValue">
                                       <?php echo e($user->city.', '.$user->country); ?>

                                    </span>
                                    
									<form id="locationForm" class="mt-3 d-flex justify-content-center align-items-center" style="display:none !important;">
										<?php echo csrf_field(); ?>
										<span class="factfileValue itemValue">
											<label>City</label>
											<input type="text" id="city_txt" name="city" class="form-control" placeholder="City" value="<?php echo e($user->city); ?>">
										
											<label>Country</label>
											<input type="text"  id="country_txt" name="country" class="form-control" placeholder="Country" value="<?php echo e($user->country); ?>">
											
											<button type="submit" class="btn btn-outline-primary btn-sm ml-3" style="    margin-top: 14px;">Update</button>
										</span>
										
									</form>
									
                                 </li>
								 
                                 <li id="bodyType">
                                    <span class="wdk-icon factfileIcon itemIcon">
                                    </span>
                                    <h4>Date of Birth<span><i class="fas fa-edit px-3" id="dob_edit" onclick="showDobForm()"></i><i class="fas fa-times px-3 d-none" id="dob_close" onclick="hideDobForm()"></i></span></h4>
                                    <span class="factfileValue itemValue"><?php echo e(date('d/m/Y',strtotime($user->b_day))); ?></span>
                                 </li>
                                 <form id="dobForm" class="mt-3 d-flex justify-content-center align-items-center" style="display:none !important;">
									<?php echo csrf_field(); ?>
									 <input type="date" name="b_day" class="form-control" placeholder="Birthday" id="bDay" value="<?php echo e(date('d/m/Y',strtotime($user->b_day))); ?>">
									 <button type="submit" class="btn btn-outline-primary btn-sm ml-3" style="margin-top: 14px;">Update</button>
								 </form>
                                 
                                 <li id="ethnicity">
                                    <span class="wdk-icon factfileIcon itemIcon">
                                    </span>
                                    <h4>Sex<span><i class="fas fa-edit px-3" id="gender_edit" onclick="showUserForm()"></i><i class="fas fa-times px-3 d-none" id="gender_close" onclick="hideUserForm()"></i></span></h4>
                                    <span class="factfileValue itemValue">
                                    <?php echo e($user->sex); ?> </span>
                                 </li>
                                 
									 <select name="sex" class="form-control" id="profile_sex" placeholder="Your sex" style="margin-left: 36px;display:none !important; width: 80% !important;" onchange="updateGender()">
										<option value=""> -- How do you identify -- </option>
										<option value="Male Straight" <?php echo e(($user->sex == "Male Straight") ? "selected" : ""); ?>>Male Straight</option>
										<option value="Female Straight" <?php echo e(($user->sex == "Female Straight")? "selected" : ""); ?>>Female Straight</option>
										<option value="Gay" <?php echo e(($user->sex == "Gay") ? "selected" : ""); ?>>Gay</option>
										<option value="Lesbian" <?php echo e(($user->sex == "Lesbian") ? "selected" : ""); ?>>Lesbian</option>
										<option value="Bisexual" <?php echo e(($user->sex == "Bisexual") ? "selected" : ""); ?>>Bisexual</option>
										<option value="Non-Binary" <?php echo e(($user->sex == "Non-Binary") ? "selected" : ""); ?>>Non-Binary</option>
										<option value="Prefer not to say" <?php echo e(($user->sex == "Prefer not to say") ? "selected" : ""); ?>>Prefer not to say</option>
									</select>
								
                              </ul>
                              

                        </div>

                           </div>
                        </div>
                     </section>
                  </div>
               </div>

            </main>
             <footer>
            <div class="container text-center">
                <div class="row py-5">
                    <div class="col-md-4 text-center">
                        <h4 class="pb-2">Follow WeGatYou</h4>
                        <a href="#"><i class="px-3 fab fa-2x fa-twitter-square"></i></a>
                        
                        <a href="#"><i class="px-3 fab fa-2x fa-instagram-square"></i></a>
                    </div>
                    <div class="col-md-4 legal pt-4 pt-md-0">
                        <a class="d-block" href="<?php echo e(url('/privacypolicy')); ?>">Privacy Policy</a>
                        <a class="d-block my-2" href="<?php echo e(url('/termsandconditions')); ?>">Terms and Conditions</a>
                        <a  class="d-block" href="<?php echo e(url('/useragreement')); ?>">User Agreement</a>
                    </div>
                    <div class="col-md-4 text-center pt-5 pt-md-2">
                        <div>
                            <img src="images/wegatyou.png"alt="">
                        </div>
                        <span>copyright &copy; 2021</span>
                    </div>
                </div>
            </div>
        </footer>
         </div>
      </div>
      <?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="<?php echo e(asset('js/profile.js')); ?>"></script>
    <script src="<?php echo e(asset('js/create_profile_image.js')); ?>"></script>
    <script>
        let favoriteDrink = <?php echo json_encode($favoriteDrink, 15, 512) ?>;
        let favoriteFood = <?php echo json_encode($favoriteFood, 15, 512) ?>;
        let food_pref = <?php echo json_encode($food_pref, 15, 512) ?>;
        
        let csrf_token = '<?php echo e(csrf_token()); ?>';
        
        function showAbtForm(){
			$('#abt-from-id').css('display','block');
			$('#abt_edit_icon').css('display','none');
			$('#abt_cross_icon').css('display','block');
			$('#abt_cross_icon').removeClass('d-none');
		}
	
		function hideAbtForm(){
			$('#abt-from-id').css('display','none');
			$('#abt_edit_icon').css('display','block');
			$('#abt_cross_icon').css('display','none');
			$('#abt_cross_icon').addClass('d-none');
		}
		
		function showLocForm(){
			$('#loc_edit').css('display','none');
			$('#loc_close').css('display','block');
			$('#loc_close').removeClass('d-none');
			$('#locationForm').css('display','block');
		}
		
		function hideLocForm(){
			$('#loc_edit').css('display','block');
			$('#loc_close').css('display','none');
			$('#locationForm').css('display','none !important;');
			$('#loc_close').addClass('d-none');
		}
		
		function showUserForm(){
			$('#profile_sex').css('display','block');
			$('#gender_edit').css('display','none');
			$('#gender_close').css('display','block');
			$('#gender_close').removeClass('d-none');
		}
		
		function hideUserForm(){
			$('#profile_sex').css('display','none');
			$('#gender_edit').css('display','block');
			$('#gender_close').css('display','none');
			$('#gender_close').addClass('d-none');
		}
		
		function updateGender(){
		
		let value = $('#profile_sex').val();
        if(value.length > 0){
            $.ajax({
                type:'POST',
                url:'/updategender',
                data:{_token : csrf_token, gender : value},
                success:function() {
                    location.reload();
                },
            });
        }
	}
	
	function showDobForm(){
		$('#dobForm').css('display','block');
		$('#dob_edit').css('display','none');
		$('#dob_close').css('display','block');
		$('#dob_close').removeClass('d-none');
	}
	
	function hideDobForm(){
		$('#dobForm').css('display','none');
		$('#dob_edit').css('display','block');
		$('#dob_close').css('display','none');
		$('#dob_close').removeClass('d-none');
	}
        
    </script>

<?php $__env->stopSection(); ?>
   </body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\datingapp\datingapp\resources\views/profile/index.blade.php ENDPATH**/ ?>