

<?php $__env->startSection('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/homepage.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top" id="main-nav">
    <div class="container">
        <a href="<?php echo e(url('/')); ?>" class="navbar-brand">
            <div class="row">
                <div class="align-self-center ml-3 mr-1">
                    <img src="images/logo.png" alt="logo" style="height: 31px">
                </div>
                <div class="align-self-center">
                    <img src="images/wegatyou.png" alt="brandtext" style="height:16px">
                </div>                        
            </div>
        </a>
    </div>
</nav>


<header id="home-section">
    <div class="dark-overlay">
        <div class="home-inner d-flex justify-content-center">
            <div class="container d-flex align-items-center justify-content-center pt-4 px-2">
                <div class="card col-md-6 col-lg-5 col-xl-4 p-0 pb-4">
                    <div class="card-body opacity-10 text-center p-0">
                        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" class="pt-4">
                        <h2 class="pt-3 pb-1">Register</h2>
                        <form action="<?php echo e(url('/register-step1')); ?> " method="POST" class="d-flex justify-content-left">
                            <?php echo csrf_field(); ?>
                            <div class="col">

                                

                                <div class="row justify-content-center col p-0 m-0 mt-3 mb-1">
                                    <i class="fas fa-user input-icon px-2"></i>
                                    <input type="text" name="name" class="input-field" placeholder="Name" id="name" value="<?php echo e(old('name')); ?>">
                                </div>

                                <?php if($errors->has('name')): ?>
                                    <div class="row justify-content-left col" id="nameMsg">
                                        <p class="m-0 erroMsg text-left">*<?php echo e($errors->first('name')); ?></p>
                                    </div>
                                <?php endif; ?>

                                

                                <div class="row justify-content-center col p-0 m-0 mt-3 mb-1">
                                    <i class="fas fa-envelope-open-text input-icon px-2"></i>
                                    <input type="text" name="email" class="input-field" placeholder="Email" id="email" value="<?php echo e(old('email')); ?>">
                                </div>

                                <?php if($errors->has('email')): ?>
                                    <div class="row justify-content-left col" id="emailMsg">
                                        <p class="m-0 erroMsg text-left">*<?php echo e($errors->first('email')); ?></p>
                                    </div>
                                <?php endif; ?>

                                

                                <div class="row justify-content-center col p-0 m-0 mt-3 mb-1">
                                    <i class="fas fa-lock input-icon px-2"></i>
                                    <input type="password" name="password" class="input-field" placeholder="Password" id="password">
                                </div>
                                <?php if($errors->has('password')): ?>
                                    <div class="row justify-content-left col" id="passwordMsg">
                                        <p class="m-0 erroMsg text-left">*<?php echo e($errors->first('password')); ?></p>
                                    </div>
                                <?php endif; ?>

                                

                                <div class="row justify-content-center col p-0 m-0 mt-3 mb-1">
                                    <i class="fas fa-key input-icon px-2"></i>
                                    <input type="password" name="password_confirmation" class="input-field" placeholder="Confirm Password" id="passwordConfirm">
                                </div>

                                

                                <div class="col p-1 pt-4">
                                    <button class="btn btn-theme btn-block" type="submit">Sign Up</button>
                                </div>
                                
                                <p class="m-0 pt-2">Or Sign up with</p>
                                <div class="col row m-0 p-0 pt-1">
                                    <button class="btn btn-facebook col m-1"><i class="fab fa-facebook-f mr-3"></i>Facebook</button>
                                    <button class="btn btn-instagram col m-1"><i class="fab fa-instagram mr-3"></i>Instagram</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/register.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u834864292/domains/ankitkapoor.in/public_html/datingapp1/resources/views/register/index.blade.php ENDPATH**/ ?>