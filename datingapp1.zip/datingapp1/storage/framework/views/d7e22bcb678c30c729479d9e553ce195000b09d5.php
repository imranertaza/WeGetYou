

<?php $__env->startSection('content'); ?>
	<div class="mainContent" aria-label="Welcome back!">
		<h1>Next step: complete the Questionaire!</h1>
		<p>You search for a soulmate starts here. The answers you give on wegatyou's affinity questionnaire helps build your own profile. This profile says what kind of person is your best match. Once completed, you can access your matches, profile and messaging.</p>
		<p>The Questionnaire is fast, user friendly and reliable. </p>
	</div>
	<div class="submitRow">
		<a class="wdk-button t-primarySkin2 next " href="<?php echo e(url('/register/questionaire/3/'.$id)); ?>"><span class="text">Continue</span></a> 
	</div>
	
<?php $__env->stopSection(); ?>
               



<?php echo $__env->make('layouts.continuesteps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u834864292/domains/ankitkapoor.in/public_html/datingapp1/resources/views/questionaire/step2.blade.php ENDPATH**/ ?>