<?php echo e($slot); ?>

<?php /**PATH /home/u834864292/domains/ankitkapoor.in/public_html/datingapp/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>