<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">    
    <title>Wegatyou</title>
    <link rel="icon" href="<?php echo e(asset('images/logo.png')); ?>">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/legal.css')); ?>">    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
    <nav class="navbar  bg-white navbar-light p-3" id="main-nav">
        <div class="container">
            <a href="<?php echo e(url('/')); ?>" class="navbar-brand">
                <div class="row">
                    <div class="align-self-center ml-3 mr-1">
                        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo" style="height: 31px">
                    </div>
                    <div class="align-self-center">
                        <img src="<?php echo e(asset('images/wegatyou.png')); ?>" alt="brandtext" style="height:16px">
                    </div>
                    <div class="align-self-center ml-3">
                        <h4 class="text-muted m-0 font-weight-bold">Legal</h4>
                    </div>                   
                </div>
            </a>
        </div>
    </nav>

    <div class="content container bg-white my-5 p-4 p-md-5">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <div class="p-4"></div>
    <footer>
        <hr>
        <div class="container">
            <span class="float-right mb-3">copyright &copy; 2021, <a href="<?php echo e(url('/')); ?>"><b>Wegatyou</b></a></span>
        </div>
    </footer>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH /home/u834864292/domains/ankitkapoor.in/public_html/datingapp1/resources/views/layouts/legal.blade.php ENDPATH**/ ?>