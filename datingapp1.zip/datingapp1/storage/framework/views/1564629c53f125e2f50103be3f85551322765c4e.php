<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1 maximum-scale=1, user-scalable=0">
		<title>Welcome</title>
		<link rel="icon" href="<?php echo e(asset('/images/logo.png')); ?>" type="image/png">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/registration_combined.css')); ?>" />
   </head>

      <body id="questionnaireContinue" class="questionnairePages" >
      <div id="pageWrapper">
         <main id="content">
            <section>
               <article>
                  <header class="tableRow">
<!--
                     <div class="tableCell">
                        <img class="brandLogo" src="<?php echo e(asset('/images/ps_logo_2016.svg')); ?>" alt="Dating with wegatyou" aria-hidden="true" />
                     </div>
-->
                  </header>
                  <?php echo $__env->yieldContent('content'); ?>
                  </article>
            </section>
         </main>
         <footer id="footerUnified" class="registrationLayout">
            <nav>
               <ul>
                   <li>
                     <a id="footerLink1" href="<?php echo e(url('/privacypolicy')); ?>">Privacy policy </a>
                  </li>
                  <li>
                     <a id="footerLink2" href="<?php echo e(url('/termsandconditions')); ?>" >Terms & conditions </a>
                  </li>
                  <li>
                     <a id="footerLink3" href="<?php echo e(url('/useragreement')); ?>" >User Agreement</a>
                  </li>
                  
               </ul>
            </nav>
         </footer>
      </div>

</html>
<?php /**PATH /home/u834864292/domains/ankitkapoor.in/public_html/datingapp/resources/views/layouts/continuesteps.blade.php ENDPATH**/ ?>