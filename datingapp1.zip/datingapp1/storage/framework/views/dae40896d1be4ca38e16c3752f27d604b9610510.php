

<?php $__env->startSection('content'); ?>
	<div class="mainContent" aria-label="Welcome back!">
		<h1>This is our affinity questionnaire, why not give it a try?</h1>
		<p>Thanks for registering, this is the beginning of a beautiful friendship!</p>
	</div>
	<div class="submitRow">
		<a class="wdk-button t-primarySkin2 next " href="<?php echo e(url('/register/questionaire/2/'.$id)); ?>"><span class="text">Continue</span></a> 
	</div>
	
<?php $__env->stopSection(); ?>
               

<?php echo $__env->make('layouts.continuesteps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u834864292/domains/ankitkapoor.in/public_html/datingapp1/resources/views/questionaire/step1.blade.php ENDPATH**/ ?>