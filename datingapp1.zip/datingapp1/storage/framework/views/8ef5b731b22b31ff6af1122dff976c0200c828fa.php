

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/homepage.css')); ?>">
    <style>
        .home-inner{
            position: static;
        }
    </style>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    
<nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top" id="main-nav">
    <div class="container">
        <a href="#" class="navbar-brand">
            <div class="row">
                <div class="align-self-center ml-3 mr-1">
                    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo" style="height: 31px">
                </div>
                <div class="align-self-center">
                    <img src="<?php echo e(asset('images/wegatyou.png')); ?>" alt="brandtext" style="height:16px">
                </div>                        
            </div>
        </a>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <form action="<?php echo e(url('/logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="nav-logout">Logout</button>
                </form>
            </li>
        </ul>
    </div>
</nav>


<header id="home-section">
    <div class="">
        <div class="home-inner d-flex justify-content-center">
            <div class="container d-flex align-items-center justify-content-center pt-4 px-2">
                <div class="card col-md-6 col-lg-5 col-xl-4 p-0 pb-4 mt-5 mb-2">
                    <div class="card-body opacity-10 text-center p-0">
                        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" class="pt-4">
                        <h2 class="pt-3 m-0">About You</h2>
                        <p class="p-0 m-0 px-4 text-success">WELCOME<br>Congrats !! You have been successfully registered.</p>
                        <P class="p-0 m-0 px-5">Please insert your presonal information to get started now !!</P>
                        <form action="<?php echo e(url('/profile')); ?> " method="POST" class="d-flex justify-content-left">
                            <?php echo csrf_field(); ?>
                            <div class="col">

                                

                                <div class="row justify-content-center col p-0 m-0 mt-3 mb-1">
                                    <i class="fas fa-user input-icon px-2"></i>
                                    <input type="text" name="first_name" class="input-field" placeholder="First name" id="firstName" value="<?php echo e(old('first_name')); ?>">
                                </div>

                                <?php if($errors->has('first_name')): ?>
                                    <div class="row justify-content-left col" id="firstNameMsg">
                                        <p class="m-0 erroMsg text-left">*<?php echo e($errors->first('first_name')); ?></p>
                                    </div>
                                <?php endif; ?>

                                

                                <div class="row justify-content-center col p-0 m-0 mt-3 mb-1">
                                    <i class="fas fa-envelope-open-text input-icon px-2"></i>
                                    <input type="text" name="last_name" class="input-field" placeholder="Last name" id="lastName" value="<?php echo e(old('last_name')); ?>">
                                </div>

                                <?php if($errors->has('last_name')): ?>
                                    <div class="row justify-content-left col" id="lastNameMsg">
                                        <p class="m-0 erroMsg text-left">*<?php echo e($errors->first('last_name')); ?></p>
                                    </div>
                                <?php endif; ?>

                                

                                <div class="row justify-content-center col p-0 m-0 mt-3 mb-1">
                                    <i class="fas fa-lock input-icon px-2"></i>
                                    <select name="sex" class="input-field" id="sex" placeholder="Your sex">
                                        <option value=""> -- How do you identify -- </option>
                                        <option <?php echo e((old('sex') == 'Male Straight')?'selected':''); ?>>Male Straight</option>
                                        <option <?php echo e((old('sex') == 'Female Straight')?'selected':''); ?>>Female Straight</option>
                                        <option <?php echo e((old('sex') == 'Gay')?'selected':''); ?>>Gay</option>
                                        <option <?php echo e((old('sex') == 'Lesbian')?'selected':''); ?>>Lesbian</option>
                                        <option <?php echo e((old('sex') == 'Bisexual')?'selected':''); ?>>Bisexual</option>
                                        <option <?php echo e((old('sex') == 'Non-Binary')?'selected':''); ?>>Non-Binary</option>
                                        <option <?php echo e((old('sex') == 'Prefer not to say')?'selected':''); ?>>Prefer not to say</option>

                                    </select>
                                </div>
                                <?php if($errors->has('sex')): ?>
                                    <div class="row justify-content-left col" id="sexMsg">
                                        <p class="m-0 erroMsg text-left">*<?php echo e($errors->first('sex')); ?></p>
                                    </div>
                                <?php endif; ?>

                                

                                <div class="row justify-content-center col p-0 m-0 mt-3 mb-1">
                                    <i class="fas fa-key input-icon px-2"></i>
                                    <input type="date" name="b_day" class="input-field" placeholder="Birthday" id="bDay" value="<?php echo e(old('b_day')); ?>">
                                </div>
                                <?php if($errors->has('b_day')): ?>
                                    <div class="row justify-content-left col" id="bDayMsg">
                                        <p class="m-0 erroMsg text-left">*<?php echo e($errors->first('b_day')); ?></p>
                                    </div>
                                <?php endif; ?>

                                

                                <div class="row justify-content-center col p-0 m-0 mt-3 mb-1">
                                    <i class="fas fa-key input-icon px-2"></i>
                                    <input type="text" name="country" class="input-field" placeholder="Country" id="country" value="<?php echo e(old('country')); ?>">
                                </div>
                                <?php if($errors->has('country')): ?>
                                    <div class="row justify-content-left col" id="countryMsg">
                                        <p class="m-0 erroMsg text-left">*<?php echo e($errors->first('country')); ?></p>
                                    </div>
                                <?php endif; ?>

                                

                                <div class="row justify-content-center col p-0 m-0 mt-3 mb-1">
                                    <i class="fas fa-key input-icon px-2"></i>
                                    <input type="text" name="region" class="input-field" placeholder="Region (Optional)" id="region" <?php echo e($errors->first('region')); ?>>
                                </div>
                                <?php if($errors->has('region')): ?>
                                    <div class="row justify-content-left col" id="regionMsg">
                                        <p class="m-0 erroMsg text-left">*<?php echo e($errors->first('region')); ?></p>
                                    </div>
                                <?php endif; ?>

                                

                                <div class="row justify-content-center col p-0 m-0 mt-3 mb-1">
                                    <i class="fas fa-key input-icon px-2"></i>
                                    <input type="text" name="city" class="input-field" placeholder="City" id="city" <?php echo e($errors->first('city')); ?>>
                                </div>
                                <?php if($errors->has('city')): ?>
                                    <div class="row justify-content-left col" id="cityMsg">
                                        <p class="m-0 erroMsg text-left">*<?php echo e($errors->first('city')); ?></p>
                                    </div>
                                <?php endif; ?>

                                

                                <div class="col p-1 pt-4">
                                    <button class="btn btn-theme btn-block" type="submit">Submit</button>
                                </div>
                                
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/create_profile.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wegatyou\resources\views/profile/create.blade.php ENDPATH**/ ?>