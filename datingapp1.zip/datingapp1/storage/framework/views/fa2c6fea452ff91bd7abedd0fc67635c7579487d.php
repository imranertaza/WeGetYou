

<?php $__env->startSection('content'); ?>
	<div class="mainContent" aria-label="Welcome back!">
		<h1>Welcome to our Compatibity Quiz</h1>
		<p>Thanks for registering! You've just completed the first step on your journey to a relationship</p>
	</div>
	<div class="submitRow">
		<a class="wdk-button t-primarySkin2 next " href="<?php echo e(url('/register/questionaire/2/'.$id)); ?>"><span class="text">Continue</span></a> 
	</div>
	
<?php $__env->stopSection(); ?>
               

<?php echo $__env->make('layouts.continuesteps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u834864292/domains/ankitkapoor.in/public_html/datingapp/resources/views/questionaire/step1.blade.php ENDPATH**/ ?>