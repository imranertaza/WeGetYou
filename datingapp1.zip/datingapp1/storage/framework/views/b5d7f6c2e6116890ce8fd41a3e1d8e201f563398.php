<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/u834864292/domains/ankitkapoor.in/public_html/datingapp/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>