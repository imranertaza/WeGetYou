<!DOCTYPE html>
<html lang="en-US">
   <head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1 maximum-scale=1, user-scalable=0">
      <title>Questionaire</title>
	  <link rel="icon" href="<?php echo e(asset('/images/logo.png')); ?>" type="image/png">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/registration_combined.css')); ?>" />

   </head>
   <body id="questionnaireQuestion" class="questionnairePages" >
      <div id="pageWrapper">
<!--
         <div id="progressBar"><i style="width:0%;" data-current-status="4"></i></div>
-->
<!--
         <header id="header">
            <img class="brandLogo" src="<?php echo e(asset('/images/ps_logo_2016.svg')); ?>" alt="Dating with wegatyou" aria-hidden="true" />
         </header>
-->
         <main id="content">
            <section>
               <form method="POST" class="d-flex justify-content-left"  action="<?php echo e(url('/saveuserhobbies')); ?> ">
                  <article class="question has-pageAnimation type_multi_column_checkbox REMOVE_FREETEXT_ANSWERS_FROM_QUESTIONNAIRE_BY_KEX "
                     data-type="MULTI_COLUMN_CHECKBOX" data-minAnswers="1" data-maxAnswers="5" data-completed="false"
                     data-bugmin-answers="1">
                     <header>
                        <h1 class="row" role="heading" aria-level="1">
                           <p class="questionText">What kind of hobbies do you have? </p>
                        </h1>
                        <div class="hintAndErrors is-static">
                           <p class="fillOutHint">(Choose up to 6 answers)</p>
                           <p class="fillOutError notEnoughAnswersGiven" role="alert">Additional details required</p>
                        </div>
                        <div class="hintAndErrors is-fixed">
                           <p class="fillOutHint">(Choose up to 6 answers)</p>
                           <p class="fillOutError notEnoughAnswersGiven" role="alert">Additional details required</p>
                        </div>
                     </header>
                     <div class="row">
                        <ul class="column">
                          
                           <?php echo csrf_field(); ?>
							<input type="hidden" name="user_id" value="<?php echo e($id); ?>">
							<?php $__currentLoopData = $hobbies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hobby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li class="answerWrapper qa-answerWrapper">
								<input type="checkbox" id="hobby<?php echo e($hobby['id']); ?>" name="hobby[]" value="<?php echo e($hobby['id']); ?>" />
								<label for="hobby<?php echo e($hobby['id']); ?>">
								<?php echo e($hobby['hobbie']); ?> </label>
							</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </ul>
                     </div>
                  </article>
                  <footer>
                     <div class="row submitRow">
                        <div class="column">
                           <button id="submitQuestionForm" class="wdk-button t-primarySkin2 next disabled wdk_loadingIndicator" type="submit" > <span class="text">Continue</span> <span class="trippleDot loader t-dark"></span> </button> 
                        </div>
                     </div>
                  </footer>
               </form>
            </section>
         </main>
         <footer id="footerUnified" class="registrationLayout">
            <nav>
               <ul>
                  <li>
                    	<a id="footerLink1" href="<?php echo e(url('/privacypolicy')); ?>">Privacy policy </a>
                    </li>
                    <li>
                    	<a id="footerLink2" href="<?php echo e(url('/termsandconditions')); ?>" >Terms & conditions </a>
                    </li>
                    <li>
                    	<a id="footerLink3" href="<?php echo e(url('/useragreement')); ?>" >User Agreement</a>
                    </li>
               </ul>
            </nav>
         </footer>
      </div>
      <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="crossorigin="anonymous"></script>
      <script>
		  var checkboxes_count = 0;
		  
		  $('input[type="checkbox"]').click(function(){
            if($(this).prop("checked") == true){
                console.log("Checkbox is checked.");
                checkboxes_count++;
            }
            else if($(this).prop("checked") == false){
                console.log("Checkbox is unchecked.");
                checkboxes_count--;
            }
            console.log(checkboxes_count);
            if(checkboxes_count <= 6){
				  $('#submitQuestionForm').removeClass('disabled');
			  }
			  else{
				  $('#submitQuestionForm').addClass('disabled');
			  }
        });
		  
      </script>
   </body>
</html>

<?php /**PATH /home/u834864292/domains/ankitkapoor.in/public_html/datingapp1/resources/views/questionaire/step5.blade.php ENDPATH**/ ?>