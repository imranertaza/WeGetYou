<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Wegatyou</title>
    <link rel="icon" href="<?php echo e(asset('images/logo.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/pay_combined.css')); ?>">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body id="runtimePage" class="paymentPages noSubnavi " >
    <nav class="navbar  bg-transparent navbar-light p-1 d-none d-lg-block" id="main-nav">
        <div class="container">
            <a href="<?php echo e(url('/')); ?>" class="navbar-brand">
                <div class="row">
                    <div class="align-self-center ml-3 mr-1">
                        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo" style="height: 31px">
                    </div>
                    <div class="align-self-center">
                        <img src="<?php echo e(asset('images/wegatyou.png')); ?>" alt="brandtext" style="height:16px">
                    </div>                        
                </div>
            </a>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item p-li">
                    <a class="nav-link" href="#pMenu" data-toggle="collapse" aria-expanded="false" aria-controls="pMenu"><div class="nav-img" style="background: url('/storage/profile_pictures/<?php echo e($user->profile_picture); ?>') center / cover no-repeat"> </div></a>
                    <div class="collapse" id="pMenu" >
                        <div class="pMenu-wrapper">
                            <div class="arrow"></div>
                            <div class="p-0 m-0 hide-arrow">
                                <a href="<?php echo e(url('/profile' )); ?>">
                                    <div class="py-2 d-flex align-items-center row m-0">
                                        <div class="col-3">
                                            <div class="nav-img" style="background: url('/storage/profile_pictures/<?php echo e($user->profile_picture); ?>') center / cover no-repeat"> </div>
                                        </div>
                                        <h6 class="d-flex justify-items-center m-0 p-0 col-9"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h6>
                                    </div>
                                </a>
                                <a href="<?php echo e(url('/subscribtion')); ?>">
                                    <div class="row p-0 m-0 d-flex align-items-center pMenu-item">
                                        <div class="col-3 p-0 text-center">
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <div class="col-9 p-0">
                                            Subscription
                                        </div>
                                    </div>
                                </a>
                                <form action="<?php echo e(url('/logout')); ?>" method="POST" class="">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="nav-logout row p-0 m-0 d-flex align-items-center"><i class="fas fa-lg fa-sign-out-alt col-3 p-0 text-center"></i><div class="col-9 p-0">Logout</div></button>
                                </form>
                            </div>
                        </div>                        
                    </div>
                </li>
            </ul>
        </div>
    </nav>
    <nav class="d-lg-none" id="nav-sm">
        <div class="fix-part">
            <div class="container d-flex justify-content-between">
                <div class="row">
                    <i class="p-3 fas fa-lg fa-bars align-self-center"></i>
                    <i class="p-3 fas fa-lg fa-times align-self-center d-none"></i>
                </div>
                <div>
                    <a href="<?php echo e(url('/')); ?>" class="navbar-brand py-3">
                        <div class="row">
                            <div class="align-self-center ml-3 mr-1">
                                <img src="images/logo.png" alt="logo" style="height: 31px">
                            </div>
                            <div class="align-self-center">
                                <img src="images/wegatyou.png" alt="brandtext" style="height:16px">
                            </div>                        
                        </div>
                    </a>
                </div>
                <div class="row sm-msg-num-wrapper">
                    <i class="p-3 fas fa-lg fa-paper-plane align-self-center pt-1"></i>
                    <span class="sm-msg-num text-center d-none"></span>
                </div>
            </div>
        </div>
        <div class="nav-rest d-none">
            <div class="container">
                <hr>

                <a href="<?php echo e(url('/profile' )); ?>">
                    <div class="py-3 d-flex align-items-center">
                        <div class="col-3 justify-content-center p-0 d-flex">
                            <div class="nav-img m-0" style="background: url('/storage/profile_pictures/<?php echo e($user->profile_picture); ?>') center / cover no-repeat"> </div>
                        </div>
                            <h6 class="d-flex justify-items-center m-0 p-0 col-9 text-left"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h6>
                    </div>
                </a>
                <hr>
                <a href="<?php echo e(url('/subscribtion')); ?>">
                    <div class="p-0 d-flex align-items-center my-3">
                        <div class="col-3 p-0 text-center">
                            <i class="fas fa-star fa-lg"></i>
                        </div>
                        <div class="col-9 p-0">Subscribtion</div>
                    </div>
                </a>
                <hr>

                <form action="<?php echo e(url('/logout')); ?>" method="POST" class="">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="logout-sm p-0 d-flex align-items-center my-3"><i class="fas fa-lg fa-sign-out-alt col-3 p-0 text-center"></i><div class="col-9 p-0">Log out</div></button>
                </form>

                <hr>
            </div>

        </div>
    </nav>

   
      <div id="pageWrapper">
         
         <main id="content">
            <!-- For Mmenu -->
            <div id="brandImage">
               <picture>
                  <!--[if IE 9]>
                  <video style="display: none;">
                     <![endif]-->
                     <source srcset="<?php echo e(asset('images/Paywall_MW_xl.jpg')); ?>" media="(min-width: 768px)">
                     <source srcset="<?php echo e(asset('images/Paywall_MW_m.jpg')); ?>" media="(min-width: 481px)">
                     <source srcset="<?php echo e(asset('images/Paywall_MW_s.jpg')); ?>" media="(max-width: 480px)">
                     <!--[if IE 9]>
                  </video>
                  <![endif]-->
                  <img src="<?php echo e(asset('images/Paywall_MW_xl.jpg')); ?>" alt="">
               </picture>
            </div>
            <section id="introLayer" class="hideInLXL tile">
               <h1>Search for matches successfully as a premium member.</h1>
               <a id="gotoPaywall" class="wdk-button t-primarySkin1 t-rightIcon " href=# >
                  <span class="icon">
                     <svg class="wdk-icon icon_arrow_right_light " role="presentation">
                        <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_arrow_right_light.svg?version=6.36.1/#icon_arrow_right_light"></use>
                     </svg>
                  </span>
                  <span class="text">View Premium plans</span> 
               </a>
            </section>
            <div id="securityBox" class="tile">
               <ul>
                  <li>
                     <div>
                        <span>
                        <img src="assets/images/trusted.png" id="securityBox_Image1img" alt=""/>
                        </span>
                     </div>
                     <p>
                        The #1 Trusted Dating Site<br><br><span>2018 Claims Study | 1,616 U.S Singles</span>
                     </p>
                  </li>
               </ul>
            </div>
            <section id="productSelection" class="tile">
               <div id="introText" class="hideInLXL">
                  <h2>Select your <strong>eharmony</strong><br> Premium Membership</h2>
               </div>
               <div class="specialOfferWrapper">
                  <div class="designWrapper">
                     <div id="discountSpecialOffer" class="specialOfferBoxStyle">
                        <div class="offerOverview">
                           <div id="counter" class="bigCountdown">
                              <p class="labelText hideInSM">This offer is only valid</p>
                              <p class="labelText hideInLXL">This offer is only valid</p>
                              <div class="remainingTime">
                                 <div class="counterContainer">
                                    <div class="wdk-countdownClock" aria-hidden="true">
                                       <div class="clockFace" data-countdown-start-ts="1621776330201" data-countdown-end-ts="1621880999000"></div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="titleWrapper hideInSM">
                              <p>Welcome Offer</p>
                           </div>
                        </div>
                        <div class="offerDetails hideInSM">
                           <h3>50% savings</h3>
                           <p>
                              on premium plus for the first month
                           </p>
                        </div>
                     </div>
                  </div>
               </div>
               <div id="baseProducts">
                  <ul class="productToggle">
                     <li id="toggle_short" >
                        <h3><strong>Premium</strong> light</h3>
                        <p>6 months</p>
                     </li>
                     <li id="toggle_hero" class="is-active">
                        <h3><strong>Premium</strong></h3>
                        <p>12 months</p>
                     </li>
                     <li id="toggle_long" >
                        <h3><strong>Gold</strong></h3>
                        <p>24 months</p>
                     </li>
                  </ul>
                  <form id="baseProduct_hero" action="/payment/runtime"
                     class="baseProduct is-active" data-product-id="1128126d-04ed-4554-bdef-2df998f98c9f" method="post">
                     <input type="hidden" name="_csrf" value="330c48a6-1278-451a-87bd-76f7a438e88d"/>
                     <input type="hidden" name="selectedOfferingId"
                        value="1128126d-04ed-4554-bdef-2df998f98c9f"/>
                     <input type="hidden" name="selectedProductIdentifier"
                        value="1128126d-04ed-4554-bdef-2df998f98c9f_PA1NXSSC23L5J9"/>
                     <div class="productHeader">
                        <h3><strong>Premium</strong></h3>
                     </div>
                     <div class="productBody">
                        <div class="productInfoText">
                           <h4 id="productNamehero">
                              <span class="wdk-icon " role="presentation">
                              <img src="<?php echo e(asset('images/icon_eh_heart.svg')); ?>" loading="lazy">
                              </span>
                              12-month plan
                           </h4>
                           <ul>
                              <li>View unlimited photos</li>
                              <li>Unlimited messaging</li>
                              <li>See who's viewed you</li>
                              <li>Distance search</li>
                              <li>Detailed personality profile</li>
                              <li class="specialItem"><strong>Most popular plan!</strong></li>
                           </ul>
                        </div>
                        <div class="priceArea">
                           <div class="stylishPrice">
                              <div class="wallPrice noFlexPrice" data-price="6,95">
                                 <span class="prefix"></span>
                                 <span class="intValueAndSep">
                                 £6.
                                 <span class="decValue" style="min-width:3ex;">
                                 99
                                 <span class="segValue">/month</span>
                                 </span>
                                 </span>
                              </div>
                           </div>
                        </div>
                        <div class="buttonArea hideInLXL">
                           <button id="submitBaseProductSM_hero" class="wdk-button t-primaryPremium t-rightIcon " type="submit" aria-describedby='productNamehero' >
                              <span class="icon">
                                 <svg class="wdk-icon icon_arrow_right_light " role="presentation">
                                    <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_arrow_right_light.svg?version=6.36.1/#icon_arrow_right_light"></use>
                                 </svg>
                              </span>
                              <span class="text">Select</span> 
                           </button>
                        </div>
                        <div class="buttonArea hideInSM">
                           <button id="submitBaseProductLXL_hero" class="wdk-button t-primarySkin1 t-rightIcon t-size_200 " type="submit" aria-describedby='productNamehero' >
                              <span class="icon">
                                 <svg class="wdk-icon icon_arrow_right_light " role="presentation">
                                    <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_arrow_right_light.svg?version=6.36.1/#icon_arrow_right_light"></use>
                                 </svg>
                              </span>
                              <a target="_blank" href="https://checkout.square.site/merchant/AZWXBTNH2ABAM/checkout/27A2ZAS7FGK2TAI4XC54EYYD?src=embed" class="text">Select this plan</a> 
                           </button>
                        </div>
                     </div>
                  </form>
                  <form id="baseProduct_long" action="/payment/runtime"
                     class="baseProduct " data-product-id="d81beab8-d2c7-4e47-98c4-893d7339cf74" method="post">
                     <input type="hidden" name="_csrf" value="330c48a6-1278-451a-87bd-76f7a438e88d"/>
                     <input type="hidden" name="selectedOfferingId"
                        value="d81beab8-d2c7-4e47-98c4-893d7339cf74"/>
                     <input type="hidden" name="selectedProductIdentifier"
                        value="d81beab8-d2c7-4e47-98c4-893d7339cf74"/>
                     <div class="productHeader">
                        <h3><strong>Gold</strong></h3>
                     </div>
                     <div class="productBody">
                        <div class="productInfoText">
                           <h4 id="productNamelong">
                              <span class="wdk-icon " role="presentation">
                              <img src="<?php echo e(asset('images/icon_eh_heart.svg')); ?>" loading="lazy">
                              </span>
                              24-month plan
                           </h4>
                           <ul>
                              <li>View unlimited photos</li>
                              <li>Unlimited messaging</li>
                              <li>See who's viewed you</li>
                              <li>Distance search</li>
                              <li>Detailed personality profile</li>
                              <li class="specialItem"><strong>Most popular plan!</strong></li>
                           </ul>
                        </div>
                        <div class="priceArea">
                           <div class="stylishPrice">
                              <div class="wallPrice noFlexPrice" data-price="10.90">
                                 <span class="prefix"></span>
                                 <span class="intValueAndSep">
                                 £10.
                                 <span class="decValue" style="min-width:3ex;">
                                 99
                                 <span class="segValue">/month</span>
                                 </span>
                                 </span>
                              </div>
                           </div>
                        </div>
                        <div class="limitedDiscount hide">
                           <p>&nbsp;</p>
                        </div>
                        <div class="buttonArea hideInLXL">
                           <button id="submitBaseProductSM_long" class="wdk-button t-primaryPremium t-rightIcon " type="submit" aria-describedby='productNamelong' >
                              <span class="icon">
                                 <svg class="wdk-icon icon_arrow_right_light " role="presentation">
                                    <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_arrow_right_light.svg?version=6.36.1/#icon_arrow_right_light"></use>
                                 </svg>
                              </span>
                              <a target="_blank" href="ttps://checkout.square.site/merchant/AZWXBTNH2ABAM/checkout/QQR5VSNQIM5XXEWZNW2Y55ZA?src=embed" class="text">Select</a> 
                           </button>
                        </div>
                        <div class="buttonArea hideInSM">
                           <a target="_blank" href="ttps://checkout.square.site/merchant/AZWXBTNH2ABAM/checkout/QQR5VSNQIM5XXEWZNW2Y55ZA?src=embed"  class="wdk-button t-primarySkin1 t-rightIcon"><span class="icon">
                                 <svg class="wdk-icon icon_arrow_right_light " role="presentation">
                                    <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_arrow_right_light.svg?version=6.36.1/#icon_arrow_right_light"></use>
                                 </svg>
                              </span>Select</a> 
                        </div>
                     </div>
                  </form>
                  <form id="baseProduct_short" action="/payment/runtime"
                     class="baseProduct " data-product-id="de544c77-c5f1-497f-9793-8f4e50612b2a" method="post">
                     <input type="hidden" name="_csrf" value="330c48a6-1278-451a-87bd-76f7a438e88d"/>
                     <input type="hidden" name="selectedOfferingId"
                        value="de544c77-c5f1-497f-9793-8f4e50612b2a"/>
                     <input type="hidden" name="selectedProductIdentifier"
                        value="de544c77-c5f1-497f-9793-8f4e50612b2a"/>
                     <div class="productHeader">
                        <h3><strong>Premium</strong> light</h3>
                     </div>
                     <div class="productBody">
                        <div class="productInfoText">
                           <h4 id="productNameshort">
                              <span class="wdk-icon " role="presentation">
                              <img src="<?php echo e(asset('images/icon_eh_heart.svg')); ?>" loading="lazy">
                              </span>
                              6-month plan
                           </h4>
                           <ul>
                              <li>View unlimited photos</li>
                              <li>Unlimited messaging</li>
                              <li>See who's viewed you</li>
                              <li>Distance search</li>
                              <li>Detailed personality profile</li>
                              <li class="specialItem"><strong>Most popular plan!</strong></li>
                           </ul>
                        </div>
                        <div class="priceArea">
                           <div class="stylishPrice">
                              <div class="wallPrice noFlexPrice" data-price="19,90">
                                 <span class="prefix"></span>
                                 <span class="intValueAndSep">
                                 £19.
                                 <span class="decValue" style="min-width:3ex;">
                                 90
                                 <span class="segValue">/month</span>
                                 </span>
                                 </span>
                              </div>
                           </div>
                        </div>
                        <div class="limitedDiscount hide">
                           <p>&nbsp;</p>
                        </div>
                        <div class="buttonArea hideInLXL">
                           <button id="submitBaseProductSM_short" class="wdk-button t-primaryPremium t-rightIcon " type="submit" aria-describedby='productNameshort' >
                              <span class="icon">
                                 <svg class="wdk-icon icon_arrow_right_light " role="presentation">
                                    <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_arrow_right_light.svg?version=6.36.1/#icon_arrow_right_light"></use>
                                 </svg>
                              </span>
                              <span class="text">Select</span> 
                           </button>
                        </div>
                        <div class="buttonArea hideInSM">
                           <a href="https://checkout.square.site/merchant/AZWXBTNH2ABAM/checkout/QUYGHVGDWFPTK73AGFPGOJ2U" class="wdk-button t-primarySkin1 t-rightIcon " target="_blank">
							   <span class="icon">
                                 <svg class="wdk-icon icon_arrow_right_light " role="presentation">
                                    <use xlink:href="/static_app/eharmony/img/icons/single_color/icon_arrow_right_light.svg?version=6.36.1/#icon_arrow_right_light"></use>
                                 </svg>
                              </span>
							   Select
							</a>
                        </div>
                     </div>
                  </form>
               </div>
               <div id="legalProductInfo" class="baseProductsText">
                  <p class="inclVAT">Applicable sales tax will be added to plan price</p>
               </div>
            </section>
            
            
            <section>
                <head>
  <!-- 1: References the Square payment library to initalize the SDK -->
  <script src="https://sandbox.web.squarecdn.com/v1/square.js"></script>
</head>
<body>
  <form id="payment-form">
    <div id="card-container"></div>
    <button id="card-button" type="button">Pay</button>
  </form>
  <!-- Configure the Web Payments SDK and Card payment method -->
  <script type="text/javascript">
    async function main() {
      const payments = Square.payments('sandbox-sq0idb-jGQK_u2d4havXk4YWnao5g', 'WDX1WFYN7TBWD');
      const card = await payments.card();
      await card.attach('#card-container');

      async function eventHandler(event) {
        event.preventDefault();

        try {
          const result = await card.tokenize();
          if (result.status === 'OK') {
            console.log(`Payment token is ${result.token}`);
          }
        } catch (e) {
          console.error(e);
        }
      };

      const cardButton = document.getElementById('card-button');
      cardButton.addEventListener('click', eventHandler);
    }

    main();
  </script>
</body>

            </section>
            
            
         </main>
         <footer id="footerUnified" class="payment">
            <nav>
               <ul>
                  <li>
                     <a id="footerLink1" href="" >About us</a>
                  </li>
                  <li>
                     <a id="footerLink2" href="" >Terms & conditions </a>
                  </li>
                  <li>
                     <a id="footerLink3" href="" rel="nofollow" >Privacy policy </a>
                  </li>
                  <li>
                     <a id="footerLink4" href="" >Help</a>
                  </li>
                  <li class="logout">
                     <a href="">Logout</a>
                  </li>
               </ul>
            </nav>
         </footer>
      </div>
	 
      </div>
   </body>
</html>
<?php /**PATH /home/u834864292/domains/ankitkapoor.in/public_html/datingapp/resources/views/subscribtion/index.blade.php ENDPATH**/ ?>